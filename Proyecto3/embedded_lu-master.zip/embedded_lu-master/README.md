embedded_lu
===========
